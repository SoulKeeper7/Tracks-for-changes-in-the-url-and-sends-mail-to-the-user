
public class HuffmanTreeNodes {

	 HuffmanTreeNodes left;
	 HuffmanTreeNodes right;
	 int val;
	 int dir;
	 String key;
	 
	 
	 public HuffmanTreeNodes(int val)
	 {
		 this.val =val;
	 }
	 
	 public HuffmanTreeNodes(int val, String key)
	 {
		 this.val =val;
		 this.key = key;
	 }
	 
	 public HuffmanTreeNodes(HuffmanTreeNodes left, HuffmanTreeNodes right)
	 {
		 this.left = left;
		 this.right = right;
	 }
	 
	 public HuffmanTreeNodes(int val, String key,HuffmanTreeNodes left, HuffmanTreeNodes right)
	 {
		 this.val =val;
		 this.key = key;
		 this.left = left;
		 this.right = right;
	 }
}


