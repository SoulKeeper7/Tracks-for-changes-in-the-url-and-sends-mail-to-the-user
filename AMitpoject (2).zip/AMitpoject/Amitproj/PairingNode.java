
public class PairingNode {



	PairingNode nextsibling = null;
	PairingNode  leftchild = null;
	PairingNode child = null;
	PairingNode left = null;
	PairingNode right = null;
	int data ;
	String key;
	int dir;
	public  PairingNode(PairingNode left, PairingNode right, int data)
	{
		this.leftchild = left;
		this.nextsibling = right;
		this.data = data;
		
	}
	
	public PairingNode( int data,String key)
	{
		this.key = key;
		this.data = data;
		
	}
	
	public PairingNode( int data)
	{
		//this.key = key;
		this.data = data;
		
	}

	public PairingNode( int data,String key, PairingNode left, PairingNode right)
	{
		this.key = key;
		this.data = data;
		this.left = left;
		this.right = right;
		
	}
	public PairingNode()
	{
		
	}
	
}





