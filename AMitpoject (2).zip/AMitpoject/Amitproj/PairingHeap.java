import java.util.ArrayList;
import java.util.List;

public class PairingHeap 
{
	 private int heapSize;
	    private static  List<PairingNode> heap;
	    public static PairingNode root = null;
	    
	  //private HuffmanNode root = null;
	 
	    /** Constructor **/    
	    public PairingHeap(int capacity)
	    {
	        heapSize = 0;
	        heap = new   ArrayList<PairingNode>(0);	     
	    }
	    
	    public PairingHeap( )
	    {
	        root = null;
	    }
	    
	    public boolean isEmpty() 
	    {
	        return root == null;
	    }
	    
	    public void makeEmpty( )
	    {
	        root = null;
	    }
	    
	    
	    public  PairingNode insert(PairingNode x)
	    {	    	
	        if (root == null)
	            root = x;
	        else
	            root = compareAndLink(root, x);
	        return root;
	    }
	    
	    
	    private static PairingNode compareAndLink(PairingNode N1, PairingNode N2)
	    {
	    	
	    	if (N2 == null)
	            return N1;
	 
	        if (N2.data < N1.data)
	        {
	        	return Attachnodes(N1, N2);
	        }
	        else
	        {	           
	            return Attachnodescase2(N1, N2);
	        }
       }

		private static PairingNode Attachnodescase2(PairingNode N1, PairingNode N2)
		{
			N2.child = N1;
			N1.nextsibling = N2.nextsibling;
			if (N1.nextsibling != null)
			    N1.nextsibling.child = N1;
			N2.nextsibling = N1.leftchild;
			if (N2.nextsibling != null)
			    N2.nextsibling.child = N2;
			N1.leftchild = N2;
			return N1;
		}

		private static PairingNode Attachnodes(PairingNode N1, PairingNode N2)
		{
			N2.child = N1.child;
			N1.child = N2;
			N1.nextsibling = N2.leftchild;
			if (N1.nextsibling != null)
			    N1.nextsibling.child = N1;
			N2.leftchild = N1;
			return N2;
		}
	    
	    public int getmin()
	    {
	    	if( root != null)
	    	return root.data;
	    	return -1;
	    }
	   public  PairingNode deleteMin()
	    {
		   if (isEmpty( ) )
	            return null;
		   PairingNode x = root;
	        if (root.leftchild == null)
	            root = null;
	        else
	            root = combinesiblings( root.leftchild );	        
	        return x;
	    }
		   
	    		    	
	private PairingNode combinesiblings(PairingNode N1Sibling)
	{
		
		 if( N1Sibling.nextsibling == null )
		 {
	            return N1Sibling;
		 }
	        
		 List<PairingNode> pairarray = new ArrayList<PairingNode>();
		 Removesiblinglinks(N1Sibling, pairarray);
	       
	        
		 int j = Firstpassmerging(pairarray);
         j = dpassmerging(pairarray, j);
	     return pairarray.get(0);	       
     }

	private int dpassmerging(List<PairingNode> pairarray, int j) {
		for ( ; j >= 2; j -= 2)
		{
		    pairarray.set(j-2,compareAndLink(pairarray.get(j-2), pairarray.get(j)));
		}
		return j;
	}

	private int Firstpassmerging(List<PairingNode> pairarray) {
		int i = 0;
		for (  ; i+1 < pairarray.size(); i += 2)	        	
		{			       
		    pairarray.set(i, compareAndLink(pairarray.get(i), pairarray.get(i + 1)));
		}
		int j=i-2;
		if(j==pairarray.size()-3)
		{
			pairarray.set(j, compareAndLink(pairarray.get(j), pairarray.get(j+2)));
			
		}
		return j;
	}

	private void Removesiblinglinks(PairingNode N1Sibling, List<PairingNode> pairarray) {
		int numSiblings =0;
		for(;N1Sibling != null;numSiblings++)
		{
		  
		    pairarray.add(N1Sibling);	            
		    N1Sibling.child.nextsibling = null; 	           
		    N1Sibling = N1Sibling.nextsibling;
		}
	}	  
	    

}