import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;

public class decoder {
	public static DecodeNode rootdec = new DecodeNode(null,"-1");	
	public static void main(String args[]) throws FileNotFoundException, IOException
	{
		if(!Files.exists(Paths.get(args[0])))
		{
			System.out.print("File not available"+args[0]);
			
			System.exit(0);
		}
		if(!Files.exists(Paths.get(args[1])))
		{
			System.out.print("File not available"+args[1]);
			
			System.exit(0);
		}
		String pathforencodebin =Paths.get(args[0]).toString();
		String pathforencodetable = Paths.get(args[1]).toString();
		Decode(pathforencodebin,pathforencodetable);

	}
	
	private static void Decode(String pathforencodebin, String pathforencodetable) throws FileNotFoundException, IOException 
	{
		//Scanner scanner = new Scanner(new FileReader(pathforencodetable));
		long startTime = System.currentTimeMillis();
		try{String currentline;
			BufferedReader br = new BufferedReader(new FileReader(pathforencodetable));
		
		//Hashtable<String,String> Frequencytable = new Hashtable<String,String>();
		
			
		 while ((currentline=br.readLine())!=null &&!currentline.isEmpty())
		    {
		    	
		    	String[] parts = currentline.split(" ");
		    	DecodeNode l=rootdec; 
		    	BuildTree(parts[0],parts[1], l);
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

			//Frequencytable.clear();
			BufferedInputStream  inputStream = new BufferedInputStream (new FileInputStream(pathforencodebin));
			
			 BufferedWriter fw = new BufferedWriter(new FileWriter("decoded.txt",true));
			 int byteRead;
			 StringBuilder sb = new StringBuilder();
			 DecodeNode v =rootdec; 
			 
			  long h=0;
			 while ((byteRead = inputStream.read()) != -1) 	            	 
			 {
		      	String s1 = String.format("%1s", Integer.toBinaryString((byteRead+256)%256));
		      	sb.append(String.format("%8s",s1).replace(" ","0"));
		      	
		      	if( sb.length()>100)
		      	{		      		
	      			for(int i=0;i<sb.length();i++)
		      			{
		      				v = Iterateandwrite(fw, sb, v, i);
			      			
		      			}
	      			sb = new StringBuilder();
		      		}		       
			 }
			 
			  		for( int i =0;i<sb.length();i++)
		      		{
			  			v = Iterateandwrite(fw, sb, v, i);
		      		}
		      	
      		if(v.key != null)      		
      		fw.write(v.key+"\n");      		
      		fw.close();
      		inputStream.close();
      		//long endTime  = System.currentTimeMillis();
			//long totalTime = endTime - startTime;
		    //System.out.println("Time for decoding is ---->"+totalTime);
	}

	private static DecodeNode Iterateandwrite(BufferedWriter fw, StringBuilder sb, DecodeNode v, int i)
			throws IOException
	{
		if(sb.charAt(i) =='0')
		{
			if(v.left == null &&v.right==null)
				{
				
				fw.write(v.key);
				fw.newLine();		      					
				v=rootdec;		      					
				}
				v= v.left;	      						
		}
		else
		{
			if(v.right == null &&v.right==null)
				{
				
				fw.write(v.key);
				fw.newLine();		      					
				v= rootdec;		      					
				}
				v= v.right;		      					
		}
		return v;
	}
	

	private static void BuildTree(String key, String code, DecodeNode root) 
	{
		
		for( int i=0;i<code.length();i++)
		{
			if(i==code.length()-1)
			{
				ifLeafNode(key, code, root, i);
			}
			else 
			{
				root = ifNotLeaf(code, root, i);
			}
		}
		
	}

	private static void ifLeafNode(String key, String code, DecodeNode root, int i) {
		if(code.charAt(i)=='0')
		{
			root.left = new DecodeNode(key,code);
		}
		else if(code.charAt(i)=='1')
		{
			root.right = new DecodeNode(key,code);
		}
	}

	private static DecodeNode ifNotLeaf(String code, DecodeNode root, int i) {
		if(code.charAt(i)=='0'&& root.left  == null)
		{
			root.left = new DecodeNode("-1","-1");
			root= root.left;
		}
		else if(root.left != null &&code.charAt(i)!='1')
		{
			root= root.left;
		}
		else if(code.charAt(i)=='1'&& root.right  == null)
		{
			root.right = new DecodeNode("-1","-1");
			root= root.right;
		}
		else if(root.right!= null &&code.charAt(i)!='0')
		{
			root= root.right;
		}
		return root;
	}

}
