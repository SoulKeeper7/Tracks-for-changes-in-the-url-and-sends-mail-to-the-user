


import java.util.ArrayList;

	import java.util.List;
	import java.util.NoSuchElementException;

	public class Heap4way
	{
	    private static final int d = 4 ;
	    private int heapSize;
	    private static  List<HuffmanTreeNodes> heap;
	 
	    /** Constructor **/    
	    public Heap4way(int capacity)
	    {
	        heapSize = 3;
	        heap = new ArrayList<HuffmanTreeNodes>(0);
	        for( int i=0;i<3;i++)
	        {
	        heap.add(new HuffmanTreeNodes(-1));
	        }
	        
	    }
	 
	    
	    public boolean isEmpty( )
	    {
	        return heapSize == 3;
	    }
	    
	    
	    private int parent(int i) 
	    {
	        return (int) (i/d)+2;
	    }
	 
	    
	    private int indexOfChild(int i, int k) 
	    {
	        return d * i + k-9;
	    }
	 
	    
	    public void insert(HuffmanTreeNodes x)
	    {	
	        heap.add(x);
	        heapSize++;
	        heapifyUp(heapSize - 1);
	    }
	 	    	 
	    
	    public HuffmanTreeNodes deleteMin()
	    {
	    	HuffmanTreeNodes keyItem = heap.get(3);
	        delete(3);
	        return keyItem;
	    }
	 
	    
	    public HuffmanTreeNodes delete(int ind)
	    {
	        if (isEmpty() )
	            throw new NoSuchElementException("Underflow Exception");
	        
	        HuffmanTreeNodes keyItem = heap.get(ind);
	        heap.set(3,heap.get(heapSize - 1));
	        heap.remove(heapSize - 1);
	        heapSize--;
	        if(!heap.isEmpty())
	        heapifyDown(ind);
	        return keyItem;
	    }
	 
	    /** Function heapifyUp  **/
	    private void heapifyUp(int lastindex)
	    {
	    	if(lastindex <=3)
	    	{
	    		return;
	    	}
	    	HuffmanTreeNodes tmp = heap.get(lastindex);    
	        while (lastindex > 3 && tmp.val < (heap.get(parent(lastindex)).val))
	        {
	            heap.set(lastindex,heap.get(parent(lastindex)));
	            lastindex = parent(lastindex);
	        }                   
	        heap.set(lastindex,tmp);
	    }
	 
	    /** Function heapifyDown **/
	    private void heapifyDown(int ind)
	    {
	  
	        int child;
	        if(heapSize <=4)
	        {
	        	return;
	        }
	        HuffmanTreeNodes tmp = heap.get(ind);
	        while (indexOfChild(ind, 1) < heapSize)
	        {
	            child = findMinChild(ind);
	            if ((heap.get(child).val <= tmp.val))
	                heap.set(ind,heap.get(child));
	            else
	            	break;
	            
	            ind = child;
	        }	        
	        heap.set(ind,tmp);
	    }
	 
	    /** Function to get smallest child **/
	    private int findMinChild(int ind) 
	    {
	        int bestChild = indexOfChild(ind, 1);
	        int k = 2;
	        int pos = indexOfChild(ind, k);
	        
	        while ((k <= d) && (pos <heapSize) ) 
	        {
	            if ((heap.get(pos).val) < (heap.get(bestChild).val))
	                bestChild = pos;	            
	            pos = indexOfChild(ind, ++k);
	        }    
	        return bestChild;
	    }
}





