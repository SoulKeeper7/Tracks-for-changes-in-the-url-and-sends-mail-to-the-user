import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;

public class encoder 
{
		private static HuffmanTreeNodes root = null;
		private static PairingNode rootpair = null;	
		private static Hashtable<String,Integer> NodesFrequencyTable = new Hashtable<String,Integer>();
		private static Hashtable<String,String> codedtable = new Hashtable<String,String>();
		
		////Starting main for encoder
		public static void main(String[] args) throws IOException
		{
			
			
			String path= null;
			Scanner scanner = null;
			try 
			{
				if(!Files.exists(Paths.get(args[0])))
				{
					System.out.print("File not available"+args[0]);
					
					System.exit(0);
				}

				path = Paths.get(args[0]).toString();
				 scanner = new Scanner(new FileReader(path));
				 
	            while (scanner.hasNextLine())
	            {
	            	String nextline = scanner.nextLine();
	                if(NodesFrequencyTable.containsKey(nextline) == false)
	                {
	                
	                	NodesFrequencyTable.put(nextline, 1);
	                }
	                else if( NodesFrequencyTable.containsKey(nextline))
	                {
	                	int x1 = NodesFrequencyTable.get(nextline);
	                	NodesFrequencyTable.replace(nextline, x1+1);
	                }
	            }
	        } 
			
			
			catch (IOException e)
			{
	            e.printStackTrace();
	        } 
			finally
			{
	                if (scanner != null) 
	                {
	                    scanner.close();
	                }
	        }
			
			create_huffman_tree_using_heaps(path);
		}

		///// creating huffman tree using different heaps
		private static void create_huffman_tree_using_heaps(String path) throws IOException, FileNotFoundException
		{
			 //creation binary heap and huffman
			//long startTime = System.currentTimeMillis();	
			//for( int i=0;i<1000;i++)
			//{				
				//Create_Tree_Using_Binry_Heap(path);				
			//}
			
		 	//long endTime  = System.currentTimeMillis();
			//long totalTime = endTime - startTime;
		    //System.out.println(totalTime);
			    
			//create using 4way
		   /*  long startTime = System.currentTimeMillis();
		     for( int i=0;i<100;i++)
			{
				create_Tree_Using_4Way(path);
			}*/
			
			create_Tree_Using_4Way(path);
		
			//create using pairing
		  // long startTime = System.currentTimeMillis();
			//for( int i=0;i<1000;i++)
			//{
			//	Create_Tree_using_Pairing(path);
			//}
			//long endTime  = System.currentTimeMillis();
			//long totalTime = endTime - startTime;
		    //System.out.println(totalTime);
		}
		
		
		private static void create_Tree_Using_4Way(String path) throws IOException, FileNotFoundException
		{
			
			Heap4way newheapobject = new Heap4way(0);					
			for(Map.Entry<String, Integer> x :NodesFrequencyTable.entrySet())
			{
				if (!x.getKey().isEmpty())
				{				
					newheapobject.insert(new HuffmanTreeNodes(x.getValue(),x.getKey()));
				}				
			}
			
				while(!newheapobject.isEmpty())
				{				
					HuffmanTreeNodes firstdeletemin = newheapobject.deleteMin();
					HuffmanTreeNodes seconddeletemin = null;
					if(!newheapobject.isEmpty())  
					{				
						seconddeletemin= newheapobject.deleteMin();
					}
					
					HuffmanTreeNodes newtrrnode = new HuffmanTreeNodes(firstdeletemin.val+seconddeletemin.val);
					
					newtrrnode.left= firstdeletemin;
					newtrrnode.left.dir=0;
					newtrrnode.right = seconddeletemin;
					newtrrnode.right.dir=1;
					root =newtrrnode;
					if(!newheapobject.isEmpty())
					{
						newheapobject.insert(newtrrnode);
					}
				}
				
			
				File file = new File("code_table.txt");
			 	FileWriter writer = new FileWriter(file,true);			        
				printPathsToLeafNodes(root,writer) ;
				writer.close();			
				Encode(path);
			}

		
		
		////creating huffman tree using binary heap
		private static void Create_Tree_using_Pairing(String path) throws IOException 
		{
			PairingHeap pairingheapobject = new PairingHeap(0);
			
			for(Map.Entry<String, Integer> x :NodesFrequencyTable.entrySet())
			{
				if(!x.getKey().isEmpty())
				{
					pairingheapobject.insert(new PairingNode(x.getValue(),x.getKey()));	
				}
			}		
			
				
			while(!pairingheapobject.isEmpty())
			{
				
			PairingNode firstmin = pairingheapobject.deleteMin();
			PairingNode secondmin = null;
				if(!pairingheapobject.isEmpty())  
				{				
					secondmin= pairingheapobject.deleteMin();
				}
				
				PairingNode newpairingheap = new PairingNode(firstmin.data+secondmin.data,"");
				
				newpairingheap.left= firstmin;
				newpairingheap.left.dir=0;
				newpairingheap.right = secondmin;
				newpairingheap.right.dir=1;
				rootpair = newpairingheap;
				if(!pairingheapobject.isEmpty())
				{
					pairingheapobject.insert(newpairingheap);
				}
				else
				{	//File file = new File("code_table.txt");
				 	//FileWriter writer = new FileWriter(file,true);				        
				 	//printPathsToLeafNodesforpairing(rootpair,writer) 	;
					//writer.close();
					//Encodeforpairing(path);					
				}
			}			
		}

		
		
		private static void Create_Tree_Using_Binry_Heap(String path) throws IOException
		{			
					
			BinaryHeap bheapobject = new BinaryHeap(0);
			for(Map.Entry<String, Integer> x :NodesFrequencyTable.entrySet())
			{
				if(!x.getKey().isEmpty())
				{				
					bheapobject.insert(new HuffmanTreeNodes(x.getValue(),x.getKey()));
				}			
			}
			
			while(!bheapobject.isEmpty())
			{				
				HuffmanTreeNodes firstmin = bheapobject.deleteMin();
				HuffmanTreeNodes secondmin = null;
				if(!bheapobject.isEmpty())  
				{
					secondmin= bheapobject.deleteMin();
				}
				
				HuffmanTreeNodes newnode = new HuffmanTreeNodes(firstmin.val+secondmin.val);
				
				newnode.left= firstmin;
				newnode.left.dir=0;
				newnode.right = secondmin;
				newnode.right.dir=1;
				if(!bheapobject.isEmpty())
				{
					bheapobject.insert(newnode);
				}
				else
				{
					//File file = new File("code_table.txt");
				 	//FileWriter writer = new FileWriter(file,true);				       
				 	//printPathsToLeafNodes(newnode,writer) 	;
					//writer.close();				
					//Encode(path);
				}				
			}
		}
		
		//////
		private static void Encode(String path) throws IOException
		{
			   BufferedReader br = null;	 
			  	try 
				{
					br = create_And_write_to_Stream(path);
				}
			  	catch (IOException e)
				{
		         e.printStackTrace();
				} 
				finally
				{
			         try 
			         {
			             if (br != null) 
			             {
			                 br.close();
			             }
			         }
			         catch (IOException ex) {
			             ex.printStackTrace();
			         }
				}
		  	}
		
		////
		private static BufferedReader create_And_write_to_Stream(String path)
				throws FileNotFoundException, IOException 
		{
			BufferedReader br;
			br = new BufferedReader(new FileReader(path));
		      String line;
		      OutputStream outputStream = new FileOutputStream("encoded.bin",true);
		      StringBuilder s = new StringBuilder();
		      while ((line = br.readLine()) != null)
		      {
					if(codedtable.containsKey(line))
					{
					   s.append(codedtable.get(line));
					   
					   while(s.length()>=8)
					   {
						String sf = s.substring(0, 8) ;          		
						int x = Integer.parseInt(sf,2) ;         	
						outputStream.write(x);
						s.delete(0, 8);
					   }
					}  
		      }
      
		      outputStream.close();
			return br;
		}

	
		private static void recursivelyPrintPaths(HuffmanTreeNodes huffnode, int path[], int pathLen,FileWriter filewriter) throws IOException 
		 {
		     if (huffnode == null)
		     {
		         return;		    
		     }
		     path[pathLen] = huffnode.dir;
		     pathLen++;
		     
		     if (huffnode.left == null && huffnode.right == null)
		     {
		         WriteCode(path, pathLen,huffnode.key,filewriter);
		     }
		     else
		     {
		    	 recursivelyPrintPaths(huffnode.left, path, pathLen,filewriter);
		    	 recursivelyPrintPaths(huffnode.right, path, pathLen,filewriter);
		     }
		 }

		
		 /////Print Array 
		private static  void WriteCode(int ints[], int len,String key,FileWriter writer) throws IOException 
		 {
		     int i;
		     StringBuilder s = new StringBuilder();
		     
		     for (i = 1; i < len; i++) 
		     {
		         s.append(ints[i]);
		     }
		     codedtable.put(key,s.toString());
		     writer.write(key+ " " +s.toString()+"\n");
		     
		 }
		
		/////Print paths
		private static void printPathsToLeafNodes(HuffmanTreeNodes huffnode,FileWriter filewriter) throws IOException 
	    {
	        int path[] = new int[1000];
	        recursivelyPrintPaths(huffnode, path, 0,filewriter);
	    }


		private static void printPathsToLeafNodesforpairing(PairingNode pnode,FileWriter filewriter) throws IOException 
	    {
	        int path[] = new int[1000];
	        recursivelyPrintPathsforpairing(pnode, path, 0,filewriter);
	    }
		
		private static void recursivelyPrintPathsforpairing(PairingNode pnode, int path[], int pathLen,FileWriter filewriter) throws IOException 
		 {
		     if (pnode == null)
		     {
		         return;		    
		     }
		     path[pathLen] = pnode.dir;
		     pathLen++;
		     
		     if (pnode.left == null && pnode.right == null)
		     {
		         WriteCodeforpairing(path, pathLen,pnode.key,filewriter);
		     }
		     else
		     {
		    	 recursivelyPrintPathsforpairing(pnode.left, path, pathLen,filewriter);
		    	 recursivelyPrintPathsforpairing(pnode.right, path, pathLen,filewriter);
		     }
		 }
		
		private static  void WriteCodeforpairing(int ints[], int len,String key,FileWriter writer) throws IOException 
		 {
		     int i;
		     StringBuilder s = new StringBuilder();
		     
		     for (i = 1; i < len; i++) 
		     {
		         s.append(ints[i]);
		     }
		     codedtable.put(key,s.toString());
		     writer.write(key+ " " +s.toString()+"\n");
		     
		 }
		
		private static void Encodeforpairing(String path) throws IOException
		{
			   BufferedReader br = null;	 
			  	try 
				{
					br = create_And_write_to_Stream_paring(path);
				}
			  	catch (IOException e)
				{
		         e.printStackTrace();
				} 
				finally
				{
			         try 
			         {
			             if (br != null) 
			             {
			                 br.close();
			             }
			         }
			         catch (IOException ex) {
			             ex.printStackTrace();
			         }
				}
		  	}
		
		private static BufferedReader create_And_write_to_Stream_paring(String path)
				throws FileNotFoundException, IOException 
		{
			BufferedReader br;
			br = new BufferedReader(new FileReader(path));
		      String line;
		      OutputStream outputStream = new FileOutputStream("encoded.bin",true);
		      StringBuilder s = new StringBuilder();
		      while ((line = br.readLine()) != null)
		      {
					if(codedtable.containsKey(line))
					{
					   s.append(codedtable.get(line));
					   
					   while(s.length()>=8)
					   {
						String sf = s.substring(0, 8) ;          		
						int x = Integer.parseInt(sf,2) ;         	
						outputStream.write(x);
						s.delete(0, 8);
					   }
					}  
		      }
      
		      outputStream.close();
			return br;
		}




}
