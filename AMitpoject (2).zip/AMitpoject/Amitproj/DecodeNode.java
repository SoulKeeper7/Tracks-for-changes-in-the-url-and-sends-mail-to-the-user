
public class DecodeNode 
{
	DecodeNode left;
	DecodeNode right;
	String key;
	String val;
	public DecodeNode(String key, String val)
	{
		this.key = key;
		this.val = val;
	}
	public DecodeNode(DecodeNode left, DecodeNode right)
	{
		this.left= left;
		this.right = right;
	}

}
