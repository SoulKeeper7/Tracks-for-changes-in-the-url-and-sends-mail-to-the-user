import java.util.ArrayList;

import java.util.List;
import java.util.NoSuchElementException;

public class BinaryHeap 
{
    private static final int d = 2
    		;
    private int BheapSize;
    private static  List<HuffmanTreeNodes> Bheap;
 
    //Constructor 
    public BinaryHeap(int capacity)
    {
        BheapSize = 0;
        Bheap = new ArrayList<HuffmanTreeNodes>(0);
       
    }
 
    //
    public boolean isEmpty( )
    {
        return BheapSize == 0;
    }
 
    /** Check if Bheap is full **/
    public boolean isFull( )
    {
        return BheapSize == Bheap.size();
    }
 
  
    
    private int parent(int i) 
    {
        return (int) Math.ceil((i-1)/d);
    }
 
    
    private int kthChild(int i, int k) 
    {
        return d * i + k;
    }
 
    /** Function to insert element */
    public void insert(HuffmanTreeNodes x)
    {
    	BheapSize++;
        Bheap.add(x);
        BheapifyUp(BheapSize - 1);
    }
 
   
    public int findMin( )
    {
        if (isEmpty() )
            throw new NoSuchElementException("Underflow Exception");           
        return Bheap.get(0).val;
    }
 
    
    public HuffmanTreeNodes deleteMin()
    {
    	HuffmanTreeNodes keyItem = Bheap.get(0);
        delete(0);
        return keyItem;
    }
 
    /** Function to delete element at an index **/
    public HuffmanTreeNodes delete(int ind)
    {
        if (isEmpty() )
            throw new NoSuchElementException("Underflow Exception");
        
        HuffmanTreeNodes keyItem = Bheap.get(ind);
       // Bheap.remove(ind);
      
        Bheap.set(0,Bheap.get(BheapSize - 1));
        Bheap.remove(BheapSize - 1);
        BheapSize--;
        if(!Bheap.isEmpty())
        BheapifyDown(ind);  
        
        return keyItem;
    }
 
    /** Function BheapifyUp  **/
    private void BheapifyUp(int childInd)
    {
    	if(childInd ==0)
    	{
    		return;
    	}
    	HuffmanTreeNodes tmp = Bheap.get(childInd);    
        while (childInd > 0 && tmp.val < (Bheap.get(parent(childInd)).val))
        {
            Bheap.set(childInd,Bheap.get(parent(childInd)));
            childInd = parent(childInd);
        }                   
        Bheap.set(childInd,tmp);
    }
 
    /** Function BheapifyDown **/
    private void BheapifyDown(int ind)
    {
  
        int child;
        
        HuffmanTreeNodes tmp = Bheap.get(ind) ;
        while (kthChild(ind, 1) < BheapSize)
        {
            child = minChild(ind);
            if ((Bheap.get(child).val <= tmp.val))
                Bheap.set(ind,Bheap.get(child));
            else
                break;
            ind = child;
        }
        Bheap.set(ind,tmp);
    }
 
    /** Function to get smallest child **/
    private int minChild(int ind) 
    {
        int bestChild = kthChild(ind, 1);
        int k = 2;
        int pos = kthChild(ind, k);
        
        while ((k <= d) && (pos <BheapSize) ) 
        {
            if (((Bheap.get(pos).val) < (Bheap.get(bestChild).val)))
                bestChild = pos;
            pos = kthChild(ind, k++);
        }
        return bestChild;
    }
 
   
	}


